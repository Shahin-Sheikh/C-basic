﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assign1
{
    class Program
    {
        static void Main(string[] args)
        {
            string fname,lname,address1,address2,city,state,zip,country;

            Console.WriteLine("Enter the name: ");
            fname = Console.ReadLine();

            Console.WriteLine("Enter the last name: ");
            lname = Console.ReadLine();

            Console.WriteLine("Enter Address Line 1: ");
            address1 = Console.ReadLine();

            Console.WriteLine("Enter Address Line 2: ");
            address2 = Console.ReadLine();

            Console.WriteLine("Enter City: ");
            city = Console.ReadLine();

            Console.WriteLine("Enter State: ");
            state = Console.ReadLine();

            Console.WriteLine("Enter Zip Code: ");
            zip = Console.ReadLine();

            Console.WriteLine("Enter Country Name: ");
            country = Console.ReadLine();

            Console.WriteLine("First Nasme is: " + fname);
            Console.WriteLine("Last Name is: " + lname);
            Console.WriteLine("Address Line 1 is: " + address1);
            Console.WriteLine("Address Line 2 is: " + address2);
            Console.WriteLine("City is: " + city);
            Console.WriteLine("State is: " + state);
            Console.WriteLine("Zip code is: " + zip);
            Console.WriteLine("Country is: " + country);
        }
    }
}
